export interface QuizQuestion {
  id: string;
  topic: string;
  difficulty: 'easy' | 'medium' | 'hard';
  selectedOptionId: string | null;
  correctOptionId: string;
  timeSpent: number;
  subjectArea: 'physics' | 'chemistry' | 'biology';
  chapterName: string;
}

export interface QuizSubmission {
  userId: string;
  quizId: string;
  score: number;
  totalQuestions: number;
  questions: QuizQuestion[];
  timestamp: string;
  totalTimeSpent: number;
  accuracy: number;
}

export interface HistoricalQuiz {
  quizId: string;
  score: number;
  totalQuestions: number;
  responseMap: Record<string, string>;
  timestamp: string;
  subjectWiseScores: SubjectScores;
}

export interface SubjectScores {
  physics: number;
  chemistry: number;
  biology: number;
}

export interface UserPerformance {
  userId: string;
  quizHistory: HistoricalQuiz[];
  averageAccuracy: number;
  weakestTopics: string[];
  strongestTopics: string[];
  recommendedStudyHours: number;
}

export interface TopicPerformance {
  topic: string;
  accuracy: number;
  questionsAttempted: number;
  averageTimeSpent: number;
  trend: 'improving' | 'declining' | 'stable';
  difficultyBreakdown: {
    easy: number;
    medium: number;
    hard: number;
  };
  recentMistakes: string[];
  recommendedResources: StudyResource[];
}

export interface StudyResource {
  type: 'video' | 'pdf' | 'quiz' | 'notes';
  title: string;
  url: string;
  duration?: number;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}

export interface RankPrediction {
  predictedRank: number;
  confidenceScore: number;
  recommendedColleges: College[];
  safetyColleges: College[];
  targetColleges: College[];
  reachColleges: College[];
  rankTrend: 'improving' | 'declining' | 'stable';
  percentile: number;
  stateRank?: number;
  categoryRank?: number;
}

export interface College {
  name: string;
  cutoffRank: number;
  location: string;
  seats: number;
  category: 'government' | 'private';
  annualFees: number;
  courseDuration: number;
  admissionRate: number;
  facilities: string[];
  specializations: string[];
  ranking: number;
  acceptanceRate: number;
  hostelFacilities: HostelInfo;
  placement: PlacementInfo;
  researchOutput: ResearchMetrics;
  alumniNetwork: AlumniInfo;
  scholarships: Scholarship[];
  entranceExams: string[];
  counselingRounds: number;
}

export interface HostelInfo {
  available: boolean;
  separateHostels: boolean;
  annualFee: number;
  facilities: string[];
  roomTypes: string[];
}

export interface PlacementInfo {
  averagePackage: number;
  highestPackage: number;
  placementPercentage: number;
  topRecruiters: string[];
}

export interface ResearchMetrics {
  publications: number;
  researchFunding: number;
  patents: number;
  researchCenters: string[];
}

export interface AlumniInfo {
  notableDoctors: string[];
  networkSize: number;
  alumniEvents: string[];
}

export interface Scholarship {
  name: string;
  amount: number;
  eligibility: string;
  type: 'merit' | 'means' | 'special';
}