import React, { useState } from 'react';
import { BarChart, Activity, Brain, School, Building2, Target, ShieldCheck, Rocket } from 'lucide-react';
import { AnalysisService } from './services/analysisService';
import { PredictionService } from './services/predictionService';
import type { QuizSubmission, UserPerformance, TopicPerformance, RankPrediction, College } from './types';

function App() {
  const [analysis, setAnalysis] = useState<TopicPerformance[]>([]);
  const [prediction, setPrediction] = useState<RankPrediction | null>(null);

  const analyzePerformance = async (quizData: QuizSubmission, historicalData: UserPerformance) => {
    const analysisService = new AnalysisService();
    const predictionService = new PredictionService();

    const topicAnalysis = analysisService.analyzeTopicPerformance(quizData, historicalData);
    const rankPrediction = predictionService.predictRank(quizData, historicalData);

    setAnalysis(topicAnalysis);
    setPrediction(rankPrediction);
  };

  const CollegeCard = ({ college, type }: { college: College, type: string }) => (
    <div className="bg-white rounded-lg shadow-md p-4 border-l-4 border-indigo-600">
      <div className="flex justify-between items-start mb-2">
        <h4 className="font-semibold text-lg">{college.name}</h4>
        <span className={`px-2 py-1 rounded-full text-xs ${
          college.category === 'government' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
        }`}>
          {college.category}
        </span>
      </div>
      <div className="grid grid-cols-2 gap-2 text-sm text-gray-600 mb-3">
        <p>Location: {college.location}</p>
        <p>Seats: {college.seats}</p>
        <p>Fees: ₹{college.annualFees.toLocaleString()}/year</p>
        <p>Duration: {college.courseDuration} years</p>
      </div>
      <div className="flex justify-between items-center text-sm">
        <span className="text-indigo-600 font-medium">
          Cutoff Rank: {college.cutoffRank.toLocaleString()}
        </span>
        <span className="text-gray-500">
          Acceptance: {(college.acceptanceRate * 100).toFixed(1)}%
        </span>
      </div>
      {college.specializations.length > 0 && (
        <div className="mt-3">
          <p className="text-xs text-gray-500 mb-1">Key Specializations:</p>
          <div className="flex flex-wrap gap-1">
            {college.specializations.map(spec => (
              <span key={spec} className="px-2 py-1 bg-gray-100 rounded-full text-xs text-gray-600">
                {spec}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-indigo-600 text-white p-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Brain className="w-8 h-8" />
            NEET Rank Predictor
          </h1>
          <p className="mt-2 text-indigo-100">Analyze your performance and predict your NEET rank</p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Performance Analysis Section */}
          <section className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold flex items-center gap-2 mb-4">
              <Activity className="w-5 h-5 text-indigo-600" />
              Topic Performance
            </h2>
            <div className="space-y-4">
              {analysis.map((topic) => (
                <div key={topic.topic} className="border-b pb-4">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="font-medium">{topic.topic}</h3>
                    <span className={`px-2 py-1 rounded-full text-sm ${
                      topic.accuracy >= 70 ? 'bg-green-100 text-green-800' :
                      topic.accuracy >= 40 ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {topic.accuracy.toFixed(1)}% Accuracy
                    </span>
                  </div>
                  <div className="text-sm text-gray-600">
                    <p>Questions Attempted: {topic.questionsAttempted}</p>
                    <p>Avg. Time per Question: {(topic.averageTimeSpent / 60).toFixed(1)} min</p>
                    <p>Trend: {topic.trend}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Rank Prediction Section */}
          <section className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold flex items-center gap-2 mb-4">
              <BarChart className="w-5 h-5 text-indigo-600" />
              Rank Prediction
            </h2>
            {prediction && (
              <div>
                <div className="text-center p-6 bg-indigo-50 rounded-lg mb-6">
                  <p className="text-sm text-indigo-600 font-medium">Predicted NEET Rank</p>
                  <p className="text-4xl font-bold text-indigo-700 mt-2">
                    {prediction.predictedRank.toLocaleString()}
                  </p>
                  <p className="text-sm text-indigo-600 mt-2">
                    Confidence Score: {prediction.confidenceScore}%
                  </p>
                </div>

                {/* College Recommendations */}
                <div className="space-y-6">
                  {/* Target Colleges */}
                  <div>
                    <h3 className="font-semibold flex items-center gap-2 mb-3">
                      <Target className="w-4 h-4 text-indigo-600" />
                      Target Colleges
                    </h3>
                    <div className="space-y-4">
                      {prediction.targetColleges.map((college) => (
                        <CollegeCard key={college.name} college={college} type="target" />
                      ))}
                    </div>
                  </div>

                  {/* Safety Colleges */}
                  <div>
                    <h3 className="font-semibold flex items-center gap-2 mb-3">
                      <ShieldCheck className="w-4 h-4 text-green-600" />
                      Safety Colleges
                    </h3>
                    <div className="space-y-4">
                      {prediction.safetyColleges.map((college) => (
                        <CollegeCard key={college.name} college={college} type="safety" />
                      ))}
                    </div>
                  </div>

                  {/* Reach Colleges */}
                  <div>
                    <h3 className="font-semibold flex items-center gap-2 mb-3">
                      <Rocket className="w-4 h-4 text-purple-600" />
                      Reach Colleges
                    </h3>
                    <div className="space-y-4">
                      {prediction.reachColleges.map((college) => (
                        <CollegeCard key={college.name} college={college} type="reach" />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </section>
        </div>
      </main>
    </div>
  );
}

export default App;