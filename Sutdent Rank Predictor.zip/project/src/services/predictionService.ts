import { QuizSubmission, UserPerformance, RankPrediction, College } from '../types';

export class PredictionService {
  // Previous year NEET cutoff ranks for reference
  private readonly PREVIOUS_YEAR_DATA = {
    maxScore: 720,
    rankRanges: [
      { scoreRange: [650, 720], rankRange: [1, 1000] },
      { scoreRange: [600, 649], rankRange: [1001, 5000] },
      { scoreRange: [550, 599], rankRange: [5001, 10000] },
      // Add more ranges based on actual data
    ],
    stateQuotas: {
      'Delhi': 0.85,
      'Maharashtra': 0.85,
      // Add more states
    }
  };

  private readonly COLLEGE_DATABASE: College[] = [
    {
      name: "AIIMS New Delhi",
      cutoffRank: 100,
      location: "New Delhi",
      seats: 125,
      category: "government",
      annualFees: 6770,
      courseDuration: 5.5,
      admissionRate: 0.1,
      facilities: ["Research Labs", "Super Specialty Hospital", "Sports Complex"],
      specializations: ["Cardiology", "Neurology", "Oncology"],
      ranking: 1,
      acceptanceRate: 0.01,
      hostelFacilities: {
        available: true,
        separateHostels: true,
        annualFee: 24000,
        facilities: ["AC Rooms", "Gym", "Reading Room"],
        roomTypes: ["Single", "Double"]
      },
      placement: {
        averagePackage: 1200000,
        highestPackage: 3600000,
        placementPercentage: 98,
        topRecruiters: ["Apollo Hospitals", "Fortis", "Max Healthcare"]
      },
      researchOutput: {
        publications: 1200,
        researchFunding: 500000000,
        patents: 45,
        researchCenters: ["Cancer Research", "Neuroscience", "Cardiology"]
      },
      alumniNetwork: {
        notableDoctors: ["Dr. Naresh Trehan", "Dr. Devi Shetty"],
        networkSize: 15000,
        alumniEvents: ["Annual Medical Conference", "Research Symposium"]
      },
      scholarships: [
        {
          name: "Merit Scholarship",
          amount: 50000,
          eligibility: "Top 1% in NEET",
          type: "merit"
        }
      ],
      entranceExams: ["NEET-UG", "AIIMS"],
      counselingRounds: 3
    },
    // Add more colleges...
  ];

  predictRank(
    currentQuiz: QuizSubmission,
    historicalData: UserPerformance
  ): RankPrediction {
    const consistencyScore = this.calculateConsistencyScore(historicalData);
    const currentPerformance = this.normalizeScore(currentQuiz.score, currentQuiz.totalQuestions);
    const historicalAverage = this.calculateHistoricalAverage(historicalData);
    const subjectBalance = this.calculateSubjectBalance(currentQuiz);

    const weightedScore = 
      (currentPerformance * 0.35) + 
      (historicalAverage * 0.35) + 
      (consistencyScore * 0.15) +
      (subjectBalance * 0.15);

    const predictedRank = this.mapScoreToRank(weightedScore);
    const { safetyColleges, targetColleges, reachColleges } = 
      this.categorizeColleges(predictedRank);
    
    return {
      predictedRank,
      confidenceScore: this.calculateConfidenceScore(consistencyScore),
      recommendedColleges: targetColleges,
      safetyColleges,
      targetColleges,
      reachColleges,
      rankTrend: this.calculateRankTrend(historicalData),
      percentile: this.calculatePercentile(predictedRank),
      stateRank: this.calculateStateRank(predictedRank, "Delhi"), // Example state
      categoryRank: this.calculateCategoryRank(predictedRank, "General") // Example category
    };
  }

  private normalizeScore(score: number, total: number): number {
    return (score / total) * this.PREVIOUS_YEAR_DATA.maxScore;
  }

  private calculateConsistencyScore(historicalData: UserPerformance): number {
    const scores = historicalData.quizHistory.map(quiz => 
      this.normalizeScore(quiz.score, quiz.totalQuestions)
    );
    
    const mean = scores.reduce((a, b) => a + b) / scores.length;
    const variance = scores.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / scores.length;
    
    return 1 - Math.sqrt(variance) / this.PREVIOUS_YEAR_DATA.maxScore;
  }

  private calculateHistoricalAverage(historicalData: UserPerformance): number {
    return historicalData.quizHistory.reduce((acc, quiz) => 
      acc + this.normalizeScore(quiz.score, quiz.totalQuestions), 0
    ) / historicalData.quizHistory.length;
  }

  private calculateSubjectBalance(quiz: QuizSubmission): number {
    const subjects = {
      physics: { total: 0, correct: 0 },
      chemistry: { total: 0, correct: 0 },
      biology: { total: 0, correct: 0 }
    };

    quiz.questions.forEach(q => {
      subjects[q.subjectArea].total++;
      if (q.selectedOptionId === q.correctOptionId) {
        subjects[q.subjectArea].correct++;
      }
    });

    const scores = Object.values(subjects).map(s => s.correct / s.total);
    const mean = scores.reduce((a, b) => a + b) / 3;
    const variance = scores.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / 3;

    return 1 - Math.sqrt(variance);
  }

  private calculateRankTrend(historicalData: UserPerformance): 'improving' | 'declining' | 'stable' {
    const recentScores = historicalData.quizHistory
      .slice(-3)
      .map(quiz => quiz.score / quiz.totalQuestions);

    if (recentScores.length < 2) return 'stable';

    const trend = recentScores[recentScores.length - 1] - recentScores[0];
    if (trend > 0.1) return 'improving';
    if (trend < -0.1) return 'declining';
    return 'stable';
  }

  private calculatePercentile(rank: number): number {
    const totalCandidates = 1800000; // Example total NEET candidates
    return ((totalCandidates - rank) / totalCandidates) * 100;
  }

  private calculateStateRank(rank: number, state: string): number {
    const stateQuota = this.PREVIOUS_YEAR_DATA.stateQuotas[state] || 0.85;
    return Math.round(rank * stateQuota);
  }

  private calculateCategoryRank(rank: number, category: string): number {
    // Implement category-wise rank calculation
    return rank; // Simplified implementation
  }

  private mapScoreToRank(score: number): number {
    const range = this.PREVIOUS_YEAR_DATA.rankRanges.find(
      r => score >= r.scoreRange[0] && score <= r.scoreRange[1]
    );

    if (!range) return 10001;

    const scorePosition = (score - range.scoreRange[0]) / 
      (range.scoreRange[1] - range.scoreRange[0]);
    
    return Math.round(
      range.rankRange[0] + 
      scorePosition * (range.rankRange[1] - range.rankRange[0])
    );
  }

  private calculateConfidenceScore(consistencyScore: number): number {
    return Math.min(consistencyScore * 100, 100);
  }

  private categorizeColleges(predictedRank: number) {
    const sortedColleges = [...this.COLLEGE_DATABASE]
      .sort((a, b) => a.cutoffRank - b.cutoffRank);

    // Safety colleges: Cutoff rank > predicted rank + 20% buffer
    const safetyColleges = sortedColleges
      .filter(college => college.cutoffRank > predictedRank * 1.2)
      .slice(0, 5);

    // Target colleges: Cutoff rank within ±10% of predicted rank
    const targetColleges = sortedColleges
      .filter(college => 
        college.cutoffRank >= predictedRank * 0.9 &&
        college.cutoffRank <= predictedRank * 1.1
      )
      .slice(0, 5);

    // Reach colleges: Cutoff rank < predicted rank - 20%
    const reachColleges = sortedColleges
      .filter(college => college.cutoffRank < predictedRank * 0.8)
      .slice(0, 3);

    return {
      safetyColleges,
      targetColleges,
      reachColleges
    };
  }
}