import { 
  QuizSubmission, 
  TopicPerformance, 
  UserPerformance,
  StudyResource 
} from '../types';

export class AnalysisService {
  private readonly STUDY_RESOURCES: Record<string, StudyResource[]> = {
    'Human Physiology': [
      {
        type: 'video',
        title: 'Complete Human Physiology',
        url: 'https://example.com/physiology',
        duration: 120,
        difficulty: 'intermediate'
      },
      // Add more resources
    ],
    // Add more topics
  };

  analyzeTopicPerformance(
    currentQuiz: QuizSubmission,
    historicalData: UserPerformance
  ): TopicPerformance[] {
    const topicMap = new Map<string, {
      correct: number;
      total: number;
      timeSpent: number;
      difficulties: Record<string, number>;
      mistakes: string[];
    }>();

    // Analyze current quiz
    currentQuiz.questions.forEach(question => {
      const topicData = topicMap.get(question.topic) || {
        correct: 0,
        total: 0,
        timeSpent: 0,
        difficulties: { easy: 0, medium: 0, hard: 0 },
        mistakes: []
      };

      topicData.total++;
      topicData.timeSpent += question.timeSpent;
      topicData.difficulties[question.difficulty]++;
      
      if (question.selectedOptionId === question.correctOptionId) {
        topicData.correct++;
      } else {
        topicData.mistakes.push(question.id);
      }

      topicMap.set(question.topic, topicData);
    });

    // Calculate performance metrics
    return Array.from(topicMap.entries()).map(([topic, data]) => ({
      topic,
      accuracy: (data.correct / data.total) * 100,
      questionsAttempted: data.total,
      averageTimeSpent: data.timeSpent / data.total,
      trend: this.calculateTrend(topic, historicalData),
      difficultyBreakdown: {
        easy: (data.difficulties.easy / data.total) * 100,
        medium: (data.difficulties.medium / data.total) * 100,
        hard: (data.difficulties.hard / data.total) * 100
      },
      recentMistakes: data.mistakes.slice(-3),
      recommendedResources: this.getRecommendedResources(topic, data.correct / data.total)
    }));
  }

  private calculateTrend(
    topic: string,
    historicalData: UserPerformance
  ): 'improving' | 'declining' | 'stable' {
    const recentScores = historicalData.quizHistory
      .slice(-3)
      .map(quiz => {
        const topicQuestions = Object.entries(quiz.responseMap)
          .filter(([qId]) => qId.startsWith(topic))
          .length;
        const correctAnswers = Object.entries(quiz.responseMap)
          .filter(([qId, ans]) => qId.startsWith(topic) && ans === 'correct')
          .length;
        return correctAnswers / topicQuestions;
      });

    if (recentScores.length < 2) return 'stable';

    const trend = recentScores[recentScores.length - 1] - recentScores[0];
    if (trend > 0.1) return 'improving';
    if (trend < -0.1) return 'declining';
    return 'stable';
  }

  private getRecommendedResources(topic: string, accuracy: number): StudyResource[] {
    const resources = this.STUDY_RESOURCES[topic] || [];
    const difficulty = accuracy < 0.4 ? 'beginner' : 
                      accuracy < 0.7 ? 'intermediate' : 
                      'advanced';
    
    return resources
      .filter(resource => resource.difficulty === difficulty)
      .slice(0, 3);
  }

  calculateSubjectWisePerformance(quiz: QuizSubmission) {
    const subjects = {
      physics: { total: 0, correct: 0 },
      chemistry: { total: 0, correct: 0 },
      biology: { total: 0, correct: 0 }
    };

    quiz.questions.forEach(q => {
      subjects[q.subjectArea].total++;
      if (q.selectedOptionId === q.correctOptionId) {
        subjects[q.subjectArea].correct++;
      }
    });

    return {
      physics: (subjects.physics.correct / subjects.physics.total) * 100,
      chemistry: (subjects.chemistry.correct / subjects.chemistry.total) * 100,
      biology: (subjects.biology.correct / subjects.biology.total) * 100
    };
  }
}